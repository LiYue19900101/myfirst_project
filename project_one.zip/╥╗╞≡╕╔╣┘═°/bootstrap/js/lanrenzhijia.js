
$(function(){
    // 控制球型出现的状态
    $('.container .labels button#label1').fadeIn(100).effect('bounce', { times:3 }, 200, function() {
        $('.container .labels button#label2').fadeIn(100).effect('bounce', { times:3 }, 200, function() {
            $('.container .labels button#label3').fadeIn(100).effect('bounce', { times:3 }, 200, function() {
                $('.container .labels button#label4').fadeIn(100).effect('bounce', { times:3 }, 200, function() {
                    $('.container .labels button#label5').fadeIn(100).effect('bounce', { times:3 }, 200);
                });
            });
        });
    });
    //关闭弹框
    $('.dialog .close').click(function() {
        $(this).parent().fadeOut(500);
        return false;
    });

    // 点击球型出现对应的详情
    $('.labels>button').click(function() {
        $('.dialog div').html( $(this).find('div').html() ).parent().fadeIn(500);
        return false;
    });
    //主题页面最下方导向箭头动效
    var next_pages=document.getElementsByClassName("next_page");
    setInterval(function(){
        for(var i=0;i<next_pages.length;i++){
            next_pages[i].style.top=next_pages[i].offsetTop+2+'px';
            if(next_pages[i].style.top==616+'px'){
                next_pages[i].style.top=600+'px';
            }
        }
    },120);

    //var clock = document.getElementById("clock");
    function initNumXY(){
        // 位置设置
        var radius = 200;//大圆半价
        var dot_num = 360/$(".dot").length;//每个div对应的弧度数
        //每一个dot对应的弧度;
        var ahd = dot_num*Math.PI/180;
        $(".dot").each(function(index, el) {
            $(this).css({
                "left":160+Math.sin((ahd*index))*radius,
                "top":165+Math.cos((ahd*index))*radius
            });
        });

    }
    initNumXY();//调用上面的函数
    var flag=true;
    $('.dot').click(function(){
        var index=$(this).index()-1;
        if(flag){
            $('.detail').eq(index).addClass('show').siblings().removeClass('show');
            flag=false;
        }else{
            $('.detail').eq(index).removeClass('show');
            flag=true;
        }

    });

    $('.share_picture').click(function(){
        if(flag){
            $('.shares').css('display',"block");
            flag=false;
        }else{
            $('.shares').css('display',"none");
            flag=true;
        }

    })

});
window._bd_share_config = {
    "common" : {
        "bdSnsKey" : {},
        "bdText" : "",
        "bdMini" : "2",
        "bdUrl" : 'http://www.yiqigan.com.cn',
        "bdPic" : "",
        "bdStyle" : "0",
        "bdSize" : "16"
    },
    "share" : {

        "bdSize" : 32,
        "tag":"share_yiqigan",
        "bdCustomStyle":"bootstrap/css/index_1.css"
    },
};
with (document)0[(getElementsByTagName('head')[0] || body).appendChild(createElement('script'))
    .src = 'http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='
    + ~(-new Date() / 36e5)];
